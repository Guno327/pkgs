#!/bin/sh
unset LC_ALL
cd "$(dirname "$0")"
./bin/satisfactory_modeler


